import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import type { Profile, Task } from '@/hooks/useTasks';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';

import { TaskCard } from './TaskCard'; // Import TaskCard

const taskSchema = z.object({
  title: z.string().min(1, { message: 'O título é obrigatório.' }).max(100, { message: 'O título deve ter no máximo 100 caracteres.' }),
  description: z.string().max(500, { message: 'A descrição deve ter no máximo 500 caracteres.' }).optional().nullable(),
  priority: z.enum(['low', 'medium', 'high'], { message: 'Prioridade inválida.' }),
  assigned_to: z.string().optional().nullable(),
  due_date: z.date().optional().nullable(),
  status: z.enum(['pending', 'in_progress', 'completed']).optional(),
});

type TaskFormValues = z.infer<typeof taskSchema>;

interface TaskDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  editingTask?: Task | null;
  profiles: Profile[];
  isLoading?: boolean; // New prop for loading state
}

export const TaskDialog = ({ isOpen, onClose, onSubmit, editingTask, profiles, isLoading }: TaskDialogProps) => {
  const form = useForm<TaskFormValues>({
    resolver: zodResolver(taskSchema),
    defaultValues: {
      title: '',
      description: '',
      priority: 'medium',
      assigned_to: '',
      due_date: undefined,
      status: 'pending',
    },
  });

  useEffect(() => {
    if (editingTask) {
      form.reset({
        title: editingTask.title,
        description: editingTask.description || '',
        priority: editingTask.priority,
        assigned_to: editingTask.assigned_to || '',
        due_date: editingTask.due_date ? new Date(editingTask.due_date) : undefined,
        status: editingTask.status as 'pending' | 'in_progress' | 'completed',
      });
    } else {
      form.reset();
    }
  }, [editingTask, isOpen, form]);

  const handleSubmit = (values: TaskFormValues) => {
    const taskData = {
      ...values,
      due_date: values.due_date ? values.due_date.toISOString() : null,
    };
    onSubmit(taskData);
  };

  const priorityLabels = {
    low: 'Baixa',
    medium: 'Média',
    high: 'Alta',
  };

  const statusLabels = {
    pending: 'Pendente',
    in_progress: 'Em Andamento',
    completed: 'Concluída',
  };

  const currentFormValues = form.watch();
  const assignedProfile = profiles.find(p => p.user_id === currentFormValues.assigned_to);

  const previewTask: Task = {
    id: editingTask?.id || 'preview-id',
    title: currentFormValues.title || 'Título da Tarefa',
    description: currentFormValues.description || 'Descrição da tarefa aqui...',
    priority: currentFormValues.priority || 'medium',
    assigned_to: currentFormValues.assigned_to || null,
    assigned_profile: assignedProfile || null,
    due_date: currentFormValues.due_date ? currentFormValues.due_date.toISOString() : null,
    status: currentFormValues.status || 'pending',
    created_at: editingTask?.created_at || new Date().toISOString(),
    updated_at: editingTask?.updated_at || new Date().toISOString(),
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px]">
        <DialogHeader>
          <DialogTitle>
            {editingTask ? 'Editar Tarefa' : 'Nova Tarefa'}
          </DialogTitle>
          <DialogDescription>
            {editingTask ? 'Atualize as informações da tarefa.' : 'Crie uma nova tarefa para a equipe.'}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(handleSubmit)} className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="title">Título</Label>
              <Input
                id="title"
                placeholder="Digite o título da tarefa"
                {...form.register('title')}
              />
              {form.formState.errors.title && (
                <p className="text-red-500 text-xs mt-1">{form.formState.errors.title.message}</p>
              )}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                placeholder="Descreva os detalhes da tarefa"
                {...form.register('description')}
                rows={3}
              />
              {form.formState.errors.description && (
                <p className="text-red-500 text-xs mt-1">{form.formState.errors.description.message}</p>
              )}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label>Prioridade</Label>
                <Select
                  value={form.watch('priority')}
                  onValueChange={(value) => form.setValue('priority', value as 'low' | 'medium' | 'high')}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a prioridade" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">{priorityLabels.low}</SelectItem>
                    <SelectItem value="medium">{priorityLabels.medium}</SelectItem>
                    <SelectItem value="high">{priorityLabels.high}</SelectItem>
                  </SelectContent>
                </Select>
                {form.formState.errors.priority && (
                  <p className="text-red-500 text-xs mt-1">{form.formState.errors.priority.message}</p>
                )}
              </div>
              {editingTask && (
                <div className="grid gap-2">
                  <Label>Status</Label>
                  <Select
                    value={form.watch('status')}
                    onValueChange={(value) => form.setValue('status', value as 'pending' | 'in_progress' | 'completed')}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">{statusLabels.pending}</SelectItem>
                      <SelectItem value="in_progress">{statusLabels.in_progress}</SelectItem>
                      <SelectItem value="completed">{statusLabels.completed}</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.status && (
                    <p className="text-red-500 text-xs mt-1">{form.formState.errors.status.message}</p>
                  )}
                </div>
              )}
            </div>
            <div className="grid gap-2">
              <Label>Responsável</Label>
              <Select
                value={form.watch('assigned_to') || ''}
                onValueChange={(value) => form.setValue('assigned_to', value || null)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um responsável" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Nenhum responsável</SelectItem>
                  {profiles.map((profile) => (
                    <SelectItem key={profile.id} value={profile.user_id}>
                      {profile.full_name || 'Usuário sem nome'}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.formState.errors.assigned_to && (
                <p className="text-red-500 text-xs mt-1">{form.formState.errors.assigned_to.message}</p>
              )}
            </div>
            <div className="grid gap-2">
              <Label>Data de Vencimento</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {form.watch('due_date') ? format(form.watch('due_date')!, "PPP", { locale: ptBR }) : "Selecione uma data"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={form.watch('due_date') || undefined}
                    onSelect={(date) => form.setValue('due_date', date || null)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
              {form.formState.errors.due_date && (
                <p className="text-red-500 text-xs mt-1">{form.formState.errors.due_date.message}</p>
              )}
            </div>
          </div>
          <div className="md:col-span-1 flex flex-col items-center justify-center p-4 border rounded-lg bg-muted/20">
            <h4 className="text-lg font-semibold mb-4">Pré-visualização do Card</h4>
            <div className="w-full max-w-xs">
              <TaskCard 
                task={previewTask} 
                onEdit={() => {}} 
                onDelete={() => {}} 
                onStatusChange={() => {}} 
                variant="kanban"
              />
            </div>
          </div>
          <DialogFooter className="md:col-span-2 flex justify-end mt-4">
            <Button type="button" variant="outline" onClick={onClose} disabled={isLoading}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? 'Salvando...' : (editingTask ? 'Atualizar' : 'Criar')} Tarefa
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};


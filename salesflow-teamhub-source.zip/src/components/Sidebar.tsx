import { Link } from "react-router-dom";
import { Home, ListTodo, DollarSign, Settings } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
interface SidebarProps {
className?: string;
}
export function Sidebar({ className }: SidebarProps) {
return (
<nav
className={cn(
"flex flex-col items-center space-y-4 px-2 py-4 bg-sidebar-background border-r border-sidebar-border",
className
)}
>
<Tooltip>
<TooltipTrigger asChild>
<Button
variant="ghost"
size="icon"
aria-label="Home"
className="rounded-lg text-sidebar-foreground hover:text-sidebar-primary"
asChild
>
<Link to="/">
<Home className="h-5 w-5" />
</Link>
</Button>
</TooltipTrigger>
<TooltipContent side="right">Home</TooltipContent>
</Tooltip>
<Tooltip>
<TooltipTrigger asChild>
<Button
variant="ghost"
size="icon"
aria-label="Tasks"
className="rounded-lg text-sidebar-foreground hover:text-sidebar-primary"
asChild
>
<Link to="/tasks">
<ListTodo className="h-5 w-5" />
</Link>
</Button>
</TooltipTrigger>
<TooltipContent side="right">Tasks</TooltipContent>
</Tooltip>
<Tooltip>
<TooltipTrigger asChild>
<Button
variant="ghost"
size="icon"
aria-label="Sales"
className="rounded-lg text-sidebar-foreground hover:text-sidebar-primary"
asChild
>
<Link to="/sales">
<DollarSign className="h-5 w-5" />
</Link>
</Button>
</TooltipTrigger>
<TooltipContent side="right">Sales</TooltipContent>
</Tooltip>
<Tooltip>
<TooltipTrigger asChild>
<Button
variant="ghost"
size="icon"
aria-label="Settings"
className="rounded-lg text-sidebar-foreground hover:text-sidebar-primary"
asChild
>
<Link to="/settings">
<Settings className="h-5 w-5" />
</Link>
</Button>
</TooltipTrigger>
<TooltipContent side="right">Settings</TooltipContent>
</Tooltip>
</nav>
);
}


import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { MoreVertical, Calendar, User, Edit, Trash2, Clock, CheckCircle, Hourglass, PlayCircle, RotateCcw } from 'lucide-react';
import { format, isPast, isToday, addDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import type { Task } from '@/hooks/useTasks';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox'; // Import Checkbox component

interface TaskCardProps {
  task: Task;
  onEdit: (task: Task) => void;
  onDelete: (id: string) => void;
  onStatusChange: (id: string, updates: { status: string }) => void;
  variant?: 'kanban' | 'list';
  onSelectTask?: (id: string, isSelected: boolean) => void; // New prop for selection
  isSelected?: boolean; // New prop for selection state
}

export const TaskCard = ({ task, onEdit, onDelete, onStatusChange, variant = 'kanban', onSelectTask, isSelected }: TaskCardProps) => {
  const priorityColors = {
    low: 'bg-green-100 text-green-800 border-green-200',
    medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    high: 'bg-red-100 text-red-800 border-red-200',
  };

  const statusColors = {
    pending: 'bg-gray-100 text-gray-800 border-gray-200',
    in_progress: 'bg-blue-100 text-blue-800 border-blue-200',
    completed: 'bg-green-100 text-green-800 border-green-200',
    overdue: 'bg-red-100 text-red-800 border-red-200',
  };

  const priorityLabels = {
    low: 'Baixa',
    medium: 'Média',
    high: 'Alta',
  };

  const statusLabels = {
    pending: 'Pendente',
    in_progress: 'Em Andamento',
    completed: 'Concluída',
    overdue: 'Atrasada',
  };

  const taskDueDate = task.due_date ? new Date(task.due_date) : null;
  const isOverdue = taskDueDate && isPast(taskDueDate) && task.status !== 'completed';
  const isDueSoon = taskDueDate && !isOverdue && !isPast(taskDueDate) && isToday(addDays(taskDueDate, -1));
  const displayStatus = isOverdue ? 'overdue' : task.status;

  const handleStatusChange = (newStatus: string) => {
    onStatusChange(task.id, { status: newStatus });
  };

  const cardClasses = `cursor-pointer hover:shadow-md transition-all duration-300 ease-in-out ${isOverdue ? 'border-red-500 border-2' : isDueSoon ? 'border-yellow-500 border-2' : ''}`;

  const getProgressBarValue = () => {
    switch (task.status) {
      case 'pending': return 25;
      case 'in_progress': return 75;
      case 'completed': return 100;
      default: return 0;
    }
  };

  const getProgressBarColor = () => {
    switch (task.status) {
      case 'pending': return 'bg-gray-400';
      case 'in_progress': return 'bg-blue-500';
      case 'completed': return 'bg-green-500';
      default: return 'bg-gray-400';
    }
  };

  if (variant === 'list') {
    return (
      <Card className={`mb-4 ${cardClasses}`}>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                {onSelectTask && (
                  <Checkbox
                    checked={isSelected}
                    onCheckedChange={(checked) => onSelectTask(task.id, checked as boolean)}
                    className="mr-2"
                  />
                )}
                <h3 className="font-semibold text-lg">{task.title}</h3>
                <Badge className={`${priorityColors[task.priority]} text-xs`}>
                  {priorityLabels[task.priority]}
                </Badge>
                <Badge className={`${statusColors[displayStatus]} text-xs`}>
                  {statusLabels[displayStatus]}
                </Badge>
              </div>
              
              {task.description && (
                <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{task.description}</p>
              )}
              
              <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground mt-2">
                {task.assigned_profile && (
                  <div className="flex items-center gap-1">
                    <Avatar className="h-5 w-5">
                      <AvatarImage src={task.assigned_profile.avatar_url} />
                      <AvatarFallback>{task.assigned_profile.full_name?.charAt(0) || '?'}</AvatarFallback>
                    </Avatar>
                    <span>{task.assigned_profile.full_name || 'Usuário sem nome'}</span>
                  </div>
                )}
                {task.due_date && (
                  <div className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    <span>{format(taskDueDate, 'dd/MM/yyyy', { locale: ptBR })}</span>
                  </div>
                )}
                {isOverdue && (
                  <div className="flex items-center gap-1 text-red-600">
                    <Clock className="h-3 w-3" />
                    <span>Atrasada</span>
                  </div>
                )}
                {isDueSoon && (
                  <div className="flex items-center gap-1 text-yellow-600">
                    <Hourglass className="h-3 w-3" />
                    <span>Vence em breve</span>
                  </div>
                )}
              </div>
              <div className="mt-3">
                <Progress value={getProgressBarValue()} className={getProgressBarColor()} />
              </div>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onEdit(task)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Editar
                </DropdownMenuItem>
                {task.status !== 'completed' && (
                  <DropdownMenuItem onClick={() => handleStatusChange('completed')}>
                    Marcar como Concluída
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem 
                  onClick={() => onDelete(task.id)}
                  className="text-destructive"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Excluir
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cardClasses}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-base font-semibold">{task.title}</CardTitle>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onEdit(task)}>
                <Edit className="h-4 w-4 mr-2" />
                Editar
              </DropdownMenuItem>
              {task.status === 'pending' && (
                <DropdownMenuItem onClick={() => handleStatusChange('in_progress')}>
                  Iniciar
                </DropdownMenuItem>
              )}
              {task.status === 'in_progress' && (
                <DropdownMenuItem onClick={() => handleStatusChange('completed')}>
                  Concluir
                </DropdownMenuItem>
              )}
              {task.status === 'completed' && (
                <DropdownMenuItem onClick={() => handleStatusChange('in_progress')}>
                  Reabrir
                </DropdownMenuItem>
              )}
              <DropdownMenuItem 
                onClick={() => onDelete(task.id)}
                className="text-destructive"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Excluir
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        {task.description && (
          <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
            {task.description}
          </p>
        )}
        
        <div className="flex flex-wrap gap-2 mb-3">
          <Badge className={`${priorityColors[task.priority]} text-xs`}>
            {priorityLabels[task.priority]}
          </Badge>
          {isOverdue && (
            <Badge className={`${statusColors.overdue} text-xs`}>
              Atrasada
            </Badge>
          )}
          {isDueSoon && (
            <Badge className={`bg-yellow-100 text-yellow-800 border-yellow-200 text-xs`}>
              Vence em breve
            </Badge>
          )}
        </div>
        
        <div className="space-y-2">
          {task.assigned_profile && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Avatar className="h-5 w-5">
                <AvatarImage src={task.assigned_profile.avatar_url} />
                <AvatarFallback>{task.assigned_profile.full_name?.charAt(0) || '?'}</AvatarFallback>
              </Avatar>
              <span>{task.assigned_profile.full_name || 'Usuário sem nome'}</span>
            </div>
          )}
          
          {task.due_date && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Calendar className="h-3 w-3" />
              <span>{format(taskDueDate, 'dd/MM/yyyy', { locale: ptBR })}</span>
            </div>
          )}
        </div>
        <div className="mt-3">
          <Progress value={getProgressBarValue()} className={getProgressBarColor()} />
        </div>
        <div className="mt-4 flex justify-end gap-2">
          {task.status === 'pending' && (
            <Button variant="outline" size="sm" onClick={() => handleStatusChange('in_progress')}>
              <PlayCircle className="h-4 w-4 mr-1" /> Iniciar
            </Button>
          )}
          {task.status === 'in_progress' && (
            <Button variant="outline" size="sm" onClick={() => handleStatusChange('completed')}>
              <CheckCircle className="h-4 w-4 mr-1" /> Concluir
            </Button>
          )}
          {task.status === 'completed' && (
            <Button variant="outline" size="sm" onClick={() => handleStatusChange('in_progress')}>
              <RotateCcw className="h-4 w-4 mr-1" /> Reabrir
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};


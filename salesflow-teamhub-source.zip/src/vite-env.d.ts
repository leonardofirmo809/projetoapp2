/// <reference types="vite/client" />
Components
/src/components/ProtectedRoute.tsx
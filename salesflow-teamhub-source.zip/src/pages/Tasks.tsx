import { useState, useMemo, useCallback } from 'react';
import { useTasks, useProfiles } from '@/hooks/useTasks';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus, ArrowLeft, Search, Trash2, CheckCircle } from 'lucide-react';
import { TaskDialog } from '@/components/TaskDialog';
import { TaskCard } from '@/components/TaskCard';
import { Link } from 'react-router-dom';
import {
  DndContext,
  closestCorners,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

interface KanbanColumnProps {
  id: string;
  title: string;
  tasks: any[];
  onEdit: (task: any) => void;
  onDelete: (id: string) => void;
  onStatusChange: (id: string, updates: { status: string }) => void;
  onSelectTask: (id: string, isSelected: boolean) => void;
  selectedTasks: string[];
}

const KanbanColumn = ({ id, title, tasks, onEdit, onDelete, onStatusChange, onSelectTask, selectedTasks }: KanbanColumnProps) => {
  const { setNodeRef } = useSortable({ id });

  return (
    <div ref={setNodeRef} className="flex flex-col min-w-[280px] bg-muted/20 p-4 rounded-lg shadow-sm">
      <h3 className="font-semibold mb-4 flex items-center gap-2">
        {title}
        <Badge variant="secondary">{tasks.length}</Badge>
      </h3>
      <div className="space-y-4 flex-grow">
        <SortableContext items={tasks.map(task => task.id)} strategy={verticalListSortingStrategy}>
          {tasks.map(task => (
            <DraggableTaskCard
              key={task.id}
              task={task}
              onEdit={onEdit}
              onDelete={onDelete}
              onStatusChange={onStatusChange}
              onSelectTask={onSelectTask}
              isSelected={selectedTasks.includes(task.id)}
            />
          ))}
        </SortableContext>
      </div>
    </div>
  );
};

interface DraggableTaskCardProps {
  task: any;
  onEdit: (task: any) => void;
  onDelete: (id: string) => void;
  onStatusChange: (id: string, updates: { status: string }) => void;
  onSelectTask: (id: string, isSelected: boolean) => void;
  isSelected: boolean;
}

const DraggableTaskCard = ({ task, onEdit, onDelete, onStatusChange, onSelectTask, isSelected }: DraggableTaskCardProps) => {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: task.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 10 : 0,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div ref={setNodeRef} style={style} {...attributes} {...listeners}>
      <TaskCard
        task={task}
        onEdit={onEdit}
        onDelete={onDelete}
        onStatusChange={onStatusChange}
        onSelectTask={onSelectTask}
        isSelected={isSelected}
      />
    </div>
  );
};

const Tasks = () => {
  const { user } = useAuth();
  const { tasks, loading, error, createTask, updateTask, deleteTask } = useTasks();
  const { profiles } = useProfiles();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPriority, setFilterPriority] = useState('');
  const [filterAssignee, setFilterAssignee] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [sortCriteria, setSortCriteria] = useState('');
  const [selectedTasks, setSelectedTasks] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false); // New state for submission loading

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor)
  );

  const filteredTasks = useMemo(() => {
    let currentTasks = tasks;

    if (searchTerm) {
      currentTasks = currentTasks.filter(
        (task) =>
          task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          task.description?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (filterPriority) {
      currentTasks = currentTasks.filter(
        (task) => task.priority === filterPriority
      );
    }

    if (filterAssignee) {
      currentTasks = currentTasks.filter(
        (task) => task.assigned_to === filterAssignee
      );
    }

    if (filterStatus) {
      currentTasks = currentTasks.filter(
        (task) => task.status === filterStatus
      );
    }

    if (sortCriteria) {
      currentTasks = [...currentTasks].sort((a, b) => {
        if (sortCriteria === 'dueDate') {
          const dateA = a.due_date ? new Date(a.due_date).getTime() : Infinity;
          const dateB = b.due_date ? new Date(b.due_date).getTime() : Infinity;
          return dateA - dateB;
        } else if (sortCriteria === 'priority') {
          const priorityOrder = { high: 3, medium: 2, low: 1 };
          return priorityOrder[b.priority] - priorityOrder[a.priority];
        }
        return 0;
      });
    }

    return currentTasks;
  }, [tasks, searchTerm, filterPriority, filterAssignee, filterStatus, sortCriteria]);

  const pendingTasks = filteredTasks.filter(task => task.status === 'pending');
  const inProgressTasks = filteredTasks.filter(task => task.status === 'in_progress');
  const completedTasks = filteredTasks.filter(task => task.status === 'completed');
  const overdueTasks = filteredTasks.filter(task => {
    if (!task.due_date) return false;
    return new Date(task.due_date) < new Date() && task.status !== 'completed';
  });

  const handleCreateTask = async (taskData: any) => {
    setIsSubmitting(true);
    const result = await createTask(taskData);
    if (result.error) {
      console.error('Erro ao criar tarefa:', result.error);
    } else {
      setIsDialogOpen(false);
    }
    setIsSubmitting(false);
  };

  const handleUpdateTask = async (id: string, updates: any) => {
    setIsSubmitting(true);
    const result = await updateTask(id, updates);
    if (result.error) {
      console.error('Erro ao atualizar tarefa:', result.error);
    }
    setIsSubmitting(false);
  };

  const handleDeleteTask = async (id: string) => {
    const result = await deleteTask(id);
    if (result.error) {
      console.error('Erro ao deletar tarefa:', result.error);
    }
  };

  const handleEditTask = (task: any) => {
    setEditingTask(task);
    setIsDialogOpen(true);
  };

  const handleDialogClose = () => {
    setIsDialogOpen(false);
    setEditingTask(null);
  };

  const handleDragEnd = useCallback((event: DragEndEvent) => {
    const { active, over } = event;

    if (!over) return;

    const taskId = active.id as string;
    const newStatus = over.id as string;

    const taskToUpdate = tasks.find(task => task.id === taskId);

    if (taskToUpdate && taskToUpdate.status !== newStatus) {
      handleUpdateTask(taskId, { status: newStatus });
    }
  }, [tasks, handleUpdateTask]);

  const handleSelectTask = useCallback((id: string, isSelected: boolean) => {
    setSelectedTasks(prevSelected =>
      isSelected ? [...prevSelected, id] : prevSelected.filter(taskId => taskId !== id)
    );
  }, []);

  const handleBatchDelete = async () => {
    if (window.confirm(`Tem certeza que deseja excluir ${selectedTasks.length} tarefas selecionadas?`)) {
      setIsSubmitting(true);
      for (const taskId of selectedTasks) {
        await deleteTask(taskId);
      }
      setSelectedTasks([]);
      setIsSubmitting(false);
    }
  };

  const handleBatchStatusChange = async (newStatus: string) => {
    setIsSubmitting(true);
    for (const taskId of selectedTasks) {
      await updateTask(taskId, { status: newStatus });
    }
    setSelectedTasks([]);
    setIsSubmitting(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Carregando tarefas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            <Link to="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold">Gerenciamento de Tarefas</h1>
              <p className="text-muted-foreground">
                Organize e acompanhe o progresso da equipe
              </p>
            </div>
          </div>
          <Button onClick={() => setIsDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Nova Tarefa
          </Button>
        </div>

        {error && (
          <div className="bg-destructive/10 border border-destructive text-destructive px-4 py-3 rounded mb-6">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-2xl">{pendingTasks.length}</CardTitle>
              <CardDescription>Pendentes</CardDescription>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-2xl">{inProgressTasks.length}</CardTitle>
              <CardDescription>Em Andamento</CardDescription>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-2xl">{completedTasks.length}</CardTitle>
              <CardDescription>Concluídas</CardDescription>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-2xl text-destructive">{overdueTasks.length}</CardTitle>
              <CardDescription>Atrasadas</CardDescription>
            </CardHeader>
          </Card>
        </div>

        <div className="flex flex-wrap gap-4 mb-6">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Buscar tarefas..."
              className="pl-9 pr-3 py-2 w-full"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <Select value={filterPriority} onValueChange={setFilterPriority}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Prioridade" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">Todas as Prioridades</SelectItem>
              <SelectItem value="low">Baixa</SelectItem>
              <SelectItem value="medium">Média</SelectItem>
              <SelectItem value="high">Alta</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filterAssignee} onValueChange={setFilterAssignee}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Responsável" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">Todos os Responsáveis</SelectItem>
              {profiles.map((profile) => (
                <SelectItem key={profile.id} value={profile.user_id}>
                  {profile.full_name || 'Usuário sem nome'}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">Todos os Status</SelectItem>
              <SelectItem value="pending">Pendente</SelectItem>
              <SelectItem value="in_progress">Em Andamento</SelectItem>
              <SelectItem value="completed">Concluída</SelectItem>
              <SelectItem value="overdue">Atrasada</SelectItem>
            </SelectContent>
          </Select>

          <Select value={sortCriteria} onValueChange={setSortCriteria}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Ordenar por" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">Sem Ordenação</SelectItem>
              <SelectItem value="dueDate">Data de Vencimento</SelectItem>
              <SelectItem value="priority">Prioridade</SelectItem>
            </SelectContent>
          </Select>

          {(searchTerm || filterPriority || filterAssignee || filterStatus || sortCriteria) && (
            <Button variant="outline" onClick={() => {
              setSearchTerm('');
              setFilterPriority('');
              setFilterAssignee('');
              setFilterStatus('');
              setSortCriteria('');
            }}>
              Limpar Filtros e Ordenação
            </Button>
          )}
        </div>

        {selectedTasks.length > 0 && (
          <div className="flex items-center gap-4 mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <span className="text-blue-800">{selectedTasks.length} tarefa(s) selecionada(s)</span>
            <Button variant="destructive" size="sm" onClick={handleBatchDelete} disabled={isSubmitting}>
              <Trash2 className="h-4 w-4 mr-2" /> Excluir Selecionadas
            </Button>
            <Select onValueChange={handleBatchStatusChange} disabled={isSubmitting}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Mudar status para" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Pendente</SelectItem>
                <SelectItem value="in_progress">Em Andamento</SelectItem>
                <SelectItem value="completed">Concluída</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}

        <Tabs defaultValue="kanban" className="w-full">
          <TabsList>
            <TabsTrigger value="kanban">Kanban</TabsTrigger>
            <TabsTrigger value="list">Lista</TabsTrigger>
          </TabsList>
          
          <TabsContent value="kanban" className="mt-6">
            <DndContext sensors={sensors} collisionDetection={closestCorners} onDragEnd={handleDragEnd}>
              <div className="overflow-x-auto pb-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 min-w-max">
                  <KanbanColumn
                    id="pending"
                    title="Pendentes"
                    tasks={pendingTasks}
                    onEdit={handleEditTask}
                    onDelete={handleDeleteTask}
                    onStatusChange={handleUpdateTask}
                    onSelectTask={handleSelectTask}
                    selectedTasks={selectedTasks}
                  />
                  <KanbanColumn
                    id="in_progress"
                    title="Em Andamento"
                    tasks={inProgressTasks}
                    onEdit={handleEditTask}
                    onDelete={handleDeleteTask}
                    onStatusChange={handleUpdateTask}
                    onSelectTask={handleSelectTask}
                    selectedTasks={selectedTasks}
                  />
                  <KanbanColumn
                    id="completed"
                    title="Concluídas"
                    tasks={completedTasks}
                    onEdit={handleEditTask}
                    onDelete={handleDeleteTask}
                    onStatusChange={handleUpdateTask}
                    onSelectTask={handleSelectTask}
                    selectedTasks={selectedTasks}
                  />
                  <KanbanColumn
                    id="overdue"
                    title="Atrasadas"
                    tasks={overdueTasks}
                    onEdit={handleEditTask}
                    onDelete={handleDeleteTask}
                    onStatusChange={handleUpdateTask}
                    onSelectTask={handleSelectTask}
                    selectedTasks={selectedTasks}
                  />
                </div>
              </div>
            </DndContext>
          </TabsContent>
          <TabsContent value="list" className="mt-6">
            <div className="space-y-4">
              {filteredTasks.map(task => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onEdit={handleEditTask}
                  onDelete={handleDeleteTask}
                  onStatusChange={handleUpdateTask}
                  variant="list"
                  onSelectTask={handleSelectTask}
                  isSelected={selectedTasks.includes(task.id)}
                />
              ))}
            </div>
          </TabsContent>
        </Tabs>

        <TaskDialog
          isOpen={isDialogOpen}
          onClose={handleDialogClose}
          onSubmit={editingTask ? (data) => handleUpdateTask(editingTask.id, data) : handleCreateTask}
          editingTask={editingTask}
          profiles={profiles}
          isLoading={isSubmitting} // Pass the loading state
        />
      </div>
    </div>
  );
};

export default Tasks;


